"""Existing fake-kubectl producer packets through the strict pure inspector."""
from copy import deepcopy
import json
from pathlib import Path
import sys
import unittest

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT / 'tests/tooling/access_telemetry_c1'))
sys.path.insert(0, str(ROOT / 'tests/tooling/access_telemetry_c1_interchange'))
sys.path.insert(0, str(ROOT / 'tools'))
from pg2_runtime_control_plane_identity_test import Pg2RuntimeControlPlaneIdentityTests, INDEX
from test_capture_commands import CaptureCommandTests
from access_telemetry_c1_capture_semantics import inspect_c115_command_declarations
from access_telemetry_c1_interchange import JsonSnapshot


class ProducerInspectionTests(unittest.TestCase):
    def test_existing_fake_kubectl_producer_packets_match_strict_inspection(self):
        harness = Pg2RuntimeControlPlaneIdentityTests()
        self.addCleanup(harness.doCleanups)
        harness.setUp()
        packet_receipts = []
        for count in (1, 2, 3):
            scenario = deepcopy(harness.base)
            for number in range(2, count + 1):
                additional = deepcopy(scenario['pods']['items'][0])
                name = harness.pod + '-extra-' + str(number)
                additional['metadata'].update(name=name, uid='fixture-extra-pod-uid-' + str(number))
                scenario['pods']['items'].append(additional)
                for field in ('metadata', 'daprdVersions', 'alphaOptIn'):
                    scenario[field][name] = deepcopy(scenario[field][harness.pod])
            scenario['pods']['items'].reverse()
            result, packets, calls, evidence = harness.run_gate(scenario)
            self.assertEqual(0, result.returncode, result.stderr)
            self.assertEqual(1, len(packets))
            raw = next(evidence.glob('*.json')).read_bytes()
            retained = JsonSnapshot(raw)
            # The producer setup needs offline fixture I/O; every pure API call
            # begins only after the same counted denial barriers as unit tests.
            barriers = CaptureCommandTests()
            barriers.setUp()
            try:
                checked = inspect_c115_command_declarations(retained)
                self.assertIs(checked.capture, retained)
                self.assertEqual(raw, checked.capture.raw)
                self.assertEqual(count, checked.pod_count)
                self.assertEqual(3 * count + 3, checked.command_count)
                self.assertEqual(tuple(tuple(argv) for argv in calls), checked.command_arguments)
                self.assertEqual(tuple(pod['metadata']['name'] for pod in scenario['pods']['items']), checked.pod_names)
                self.assertEqual({}, barriers.dependency_calls)
                packet_receipts.append({'podCount': checked.pod_count, 'podNames': checked.pod_names,
                                        'commandCount': checked.command_count, 'captureSha256': checked.capture.sha256,
                                        'captureByteLength': len(raw), 'sourceDisposition': checked.capture.value['sourceDisposition'],
                                        'dependencyAttempts': barriers.dependency_calls})
            finally:
                barriers.doCleanups()
            (Path('/tmp') / ('story-27-4-capture-verification-producer-' + str(count) + '-pods.json')).write_bytes(raw)
        print(json.dumps(packet_receipts, indent=2))


if __name__ == '__main__':
    unittest.main(verbosity=2)
