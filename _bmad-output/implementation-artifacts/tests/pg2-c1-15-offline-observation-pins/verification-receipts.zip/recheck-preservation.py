"""Offline working-byte receipt comparison; no application code is imported."""
import hashlib
import json
from pathlib import Path
import subprocess

receipt_dir = Path(__file__).resolve().parent
baseline = json.loads((receipt_dir / 'baseline.json').read_bytes())
ledger = '_bmad-output/specs/spec-pg2-c1-authenticated-predecessor-interchange/implementation-tasks.md'
changed = []
for name, expected in baseline['files'].items():
    if name == ledger:
        continue
    path = Path(name)
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        changed.append(name)
prefix = (receipt_dir / 'implementation-tasks-before.bin').read_bytes()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
gitlinks = ''.join(line + '\n' for line in subprocess.check_output(['git', 'ls-files', '--stage'], text=True).splitlines() if line.startswith('160000 '))
allowed = set(baseline['initial_changed_paths']) | {
    '_bmad-output/implementation-artifacts/spec-pg2-c1-15-offline-observation-pins.md',
    'tools/access_telemetry_c1_capture_semantics.py',
    'tests/tooling/access_telemetry_c1_interchange/test_capture_semantics.py',
    'docs/operations/c1-observation-pin-inspection-contract.md',
    '_bmad-output/implementation-artifacts/tests/pg2-c1-15-offline-observation-pins/verification-receipts.zip',
}
status = subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all', '-z']).decode().split('\0')
changed_paths = {entry[3:] for entry in status if entry}
report = {
    'baseline_file_count': len(baseline['files']),
    'compared_existing_nonledger_file_count': len(baseline['files']) - 1,
    'changed_existing_nonledger_files': changed,
    'ledger_prior_prefix_length': len(prefix),
    'ledger_prior_prefix_matches': Path(ledger).read_bytes().startswith(prefix),
    'ledger_appended_byte_count': len(Path(ledger).read_bytes()) - len(prefix),
    'head_matches': head == baseline['head'],
    'root_gitlinks_match': gitlinks == baseline['gitlinks'],
    'unexpected_changed_paths': sorted(changed_paths - allowed),
}
(receipt_dir / 'implementation-preservation-check.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
assert not changed and report['ledger_prior_prefix_matches'] and report['head_matches'] and report['root_gitlinks_match'] and not report['unexpected_changed_paths']
